<!DOCTYPE html>
<html>
<head>
  <meta charset='UTF-8'>
  <title>Locate Share</title>
    <link rel="stylesheet" type="text/css" href="/css/style.css">
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?language=ja&region=JP&key=AIzaSyDaHql2rBljc157mV2Xdf-W8cc60fbcgeg&callback=initMap" async defer>
    </script>
    </head>
<body>
<header>
  <div class='logo'>
    <a href='/index.php'>Locate Share</a>
  </div>
  <div class='menus'>
    <div class='links'><a href='index.php'>Index<a></div>
    <div class='links'><a href='#'></a></div>
    <div class='links'><a href='favorite.php'>Favorite</a></div>
    <div class='links'><a href='follow_locate.php'>Follows</a></div>
  </div>
  <div class='logout'><a href='logout.php'>ログアウト</a></div>
</header>
